<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Quiz</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all.css')); ?>">
    <script src="<?php echo e(asset('assets/js/jquery-3.6.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
</head>
<body>

    <div class="container">
        <div class="row">
            <div class="col">
                <h1 class="text-center mt-5">Quiz da profissão</h1>
            </div>
        </div>
    </div>

</body>
</html>
<?php /**PATH C:\Users\Ozeas\Desktop\projetos\quiz\resources\views/welcome.blade.php ENDPATH**/ ?>